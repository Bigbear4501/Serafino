# Das Eltern-Kontrollzentrum – kurz erklärt

Das Kontrollzentrum ist euer Werkzeugkasten. Ihr öffnet es über das Symbol **„Eltern-Kontrollzentrum“** auf dem Schreibtisch oder im Startmenü. Kinder sehen es nicht.

Was Administrator-Rechte braucht, fragt nach dem **Eltern-Passwort**. Danach merkt sich Pingulinux das Passwort für ein paar Minuten, ihr müsst es also nicht bei jedem Klick neu eingeben.

---

## Die Kacheln

### Bildschirmzeit

Für jedes Kind seht ihr, wie lange es heute schon am Computer war und wie viel Zeit noch übrig ist.

- **+15 / +30 / +60 Min. heute:** Extrazeit nur für heute, zum Beispiel für die Hausaufgaben.
- **Montag bis Freitag** und **Samstag und Sonntag:** wie viele Minuten am Tag erlaubt sind.
- **Erlaubt von … bis … Uhr:** zu welcher Tageszeit das Kind den Computer benutzen darf.
- Mit **„Regeln speichern“** übernehmen.

Das Kind sieht seine Restzeit in der Taskleiste als gut lesbares Feld **„⏳ Noch 45 Min“** – grün, ab 15 Minuten gelb, ab 5 Minuten rot. Bei **15, 5 und 1 Minute** sagt Fino Bescheid (großes Fenster, vorgelesen), damit Bilder und Spiele rechtzeitig gespeichert werden. Bei den Kleinen zeigt die Sonne auf dem Startbildschirm die Zeit.

Ist die Zeit um, meldet Pingulinux das Kind ab.

### Benutzerkonten

Hier legt ihr Kinderkonten an, ändert Passwörter und Profilbilder oder löscht ein Konto.

Beim Anlegen gebt ihr den **Geburtstag** an (Tag, Monat und Jahr). Damit **wächst das Alter mit**, genau am Geburtstag: Erlaubte Programme und Sperren passen sich von selbst an, wenn das Kind älter wird. Programme, für die das Kind noch zu jung ist, erscheinen in seinem Startmenü gar nicht erst.

Für die Kleinen (2 bis 6 Jahre) könnt ihr **Anmelden ohne Passwort** einschalten – gleich beim Anlegen oder später unter „Anmelden ohne Passwort“. Mehr dazu im Thema „Anmelden ohne Passwort“.

**Tipp:** Legt für beide Eltern ein eigenes Konto mit Eltern-Rechten an. Dann kann einer das Passwort des anderen zurücksetzen, falls es vergessen wurde.

### Konten-Übersicht

Alle Kinderkonten auf einen Blick, mit Alter und Bildschirmzeit.

### Nutzung

Wie lange war ein Kind am Computer, und womit? Oben steht die Zeit von heute, gestern und im Schnitt pro Tag der letzten Woche. Darunter die Bildschirmzeit der letzten 14 Tage als Säulen und die Programme der letzten 7 Tage – wie lange sie geöffnet waren.

Gespeichert werden nur Bildschirmzeit, Programmname und Minuten – keine Webseiten, keine Fenstertitel, keine Inhalte. Die Daten bleiben auf diesem Computer, nur Eltern-Konten können sie sehen, und nach 30 Tagen werden sie gelöscht. Nichts geht ins Internet.

### YouTube Kids

Hier stellt ihr ein, ob Kinder YouTube Kids **selbst starten** dürfen (so ist es ab Werk) oder **nur mit dem Eltern-Passwort** – dann schaut ihr gemeinsam: Beim Öffnen gibt ein Erwachsener das Passwort ein. Die Einstellung gilt für alle Kinderkonten und bleibt auch nach Updates erhalten.

### Startbildschirm der Kleinen

Für Kinder **bis 6 Jahre** startet nach dem Anmelden ein eigener, einfacher Startbildschirm: wenige große Bild-Kacheln, Fino oben und eine **Sonne, die im Lauf der erlaubten Zeit langsam untergeht**. Jede Kachel hat oben rechts einen **Vorlese-Knopf 🗣️**: Der liest nur den Namen vor („Malen“), startet aber nichts – so können Kinder, die noch nicht lesen, in Ruhe ausprobieren. Ein Tipp auf die Kachel selbst startet das Programm (und sagt den Namen dazu).

Oben gibt es große Knöpfe **🔉 leiser** und **🔊 lauter** mit Balken dazwischen. Lauter als eure Obergrenze geht es nicht – auch nicht über die Lautstärke-Tasten. Die Obergrenze (Vorgabe **70 %**, schont die Ohren, gerade mit Kopfhörern) stellt ihr beim Einrichten der Kacheln unter „Höchste Lautstärke“ ein.

- **Kacheln einrichten:** Nur hier im Kontrollzentrum (Kachel „Startbildschirm der Kleinen“). Angeboten werden nur Programme, die zum Alter passen. Auf dem Startbildschirm selbst gibt es keinen „Hinzufügen“-Knopf – so landen Kinder nicht aus Versehen bei der Passwort-Abfrage.
- **Nach Hause 🏠:** Solange ein Programm läuft, das vom Startbildschirm aus gestartet wurde, liegt unten links ein runder Knopf mit einem Haus über allem. Antippen beendet das Programm und bringt das Kind zurück zum Startbildschirm. Damit der Knopf nie verdeckt wird, öffnen sich Spiele und Videos in diesem Konto nicht im echten Vollbild, sondern als großes Fenster.
- **Gruppen:** Mehrere Programme lassen sich zu einer Kachel zusammenfassen, zum Beispiel „Spielen“. Beim Antippen öffnet sich eine zweite Seite mit einem großen „Zurück“-Knopf.
- **Umbenennen:** Doppelklick auf einen Eintrag, zum Beispiel „Malen“ statt „Tux Paint“. Dieser Name wird auch vorgelesen.
- **Ab 7 Jahren** gibt es automatisch den normalen Bildschirm. Ihr könnt das pro Kind auf „immer“ oder „nie“ umstellen.
- Unten rechts führt **„🔒 Normaler Bildschirm (Eltern)“** zum gewohnten KDE – nur mit dem Eltern-Passwort. Zurück geht es über „Mein Startbildschirm“ im Startmenü oder in der Taskleiste.

Gespeichert wird nur mit dem Eltern-Passwort, Kinder können also nichts hinzufügen oder löschen.

### Kinderschutz-Filter

Blockiert im ganzen Computer Seiten mit Erwachsenen- und Gewaltinhalten. Zur Wahl stehen:

- **CleanBrowsing Family** (Standard)
- **DNS4EU Kinderschutz** (europäischer Dienst)
- **Aus**

Kinder können den Filter nicht selbst umstellen. Zusätzlich sind **YouTube und soziale Netzwerke für Kinder unter 13 Jahren gesperrt**, auch im privaten Fenster. Für Kinder gibt es dafür **YouTube Kids** im eigenen Fenster, ohne Adressleiste und ohne Browser.

Landet ein Kind auf einer gesperrten Seite, zeigt Firefox statt einer technischen Fehlermeldung **Fino**: „Diese Seite ist gesperrt – frag Mama oder Papa.“ Unter „Für Erwachsene“ steht auf dieser Seite, welche Adresse es war und warum sie nicht geht. Genauso freundlich reagiert Pingulinux, wenn ein Kind ein Programm öffnen will, für das es noch zu jung ist, oder das Terminal (Strg+Alt+T).

### Firewall

Die Firewall ist ab Werk eingeschaltet und schützt den Computer vor Zugriffen aus dem Netz. Normalerweise müsst ihr hier nichts ändern. Drucker im Heimnetz werden trotzdem gefunden.

### App Store

Ausgesuchte, kindgeeignete Programme zum Installieren und wieder Entfernen. Jedes Programm hat eine **Altersangabe**: Ein Kind sieht nur, was zu seinem Alter passt.

Einige größere Programme sind nicht vorinstalliert, sondern liegen hier bereit, zum Beispiel **SuperTuxKart**, **Stellarium**, **Krita**, **Kalzium** und **Thunderbird**.

### Sicherung

Pingulinux sichert das **System jeden Tag von selbst** auf der Festplatte. Hier könnt ihr außerdem:

- **System jetzt sichern**, zum Beispiel vor einer großen Änderung.
- **Auf USB-Stick sichern:** eigene Dateien (Fotos, Dokumente) aller Konten und, wenn ihr wollt, das System.
- **Eigene Dateien vom Stick zurückholen.**
- **Sicherungen ansehen und System wiederherstellen.**

Oben im Kontrollzentrum steht immer, wann die letzte tägliche Sicherung lief. Läuft nach einem Update etwas nicht mehr, hilft der Knopf **„Gestern wiederherstellen …“**. Eigene Dateien bleiben beim Wiederherstellen unverändert.

### Update-Assistent

Installiert Sicherheits-Updates und neue Programmversionen. Gibt es eine neue Debian-Version, hilft er auch beim Wechsel und legt vorher eine Sicherung an. Bitte das Gerät dabei am Strom lassen.

### Systembereinigung

Entfernt nicht mehr benötigte Pakete, heruntergeladene Installationsdateien und ungenutzte Flatpak-Teile und schafft so Platz auf der Festplatte.

### Drucker und Scanner

Öffnet die KDE-Druckereinstellungen. Die meisten Drucker im Heimnetz werden von selbst gefunden.

### Hardware & Treiber

Pingulinux bringt freie Treiber für fast alles schon mit. Diese Kachel zeigt, welche Grafikkarte, welches WLAN und welcher Kernel im Computer stecken, und bietet Zusätze nur dort an, wo sie etwas bringen:

- **Nvidia-Grafik:** Der Nvidia-Treiber ist schneller bei 3D-Spielen. Pingulinux sucht die passende Version selbst aus. Sehr alte Nvidia-Karten (etwa vor 2014) unterstützt Debian 13 nicht mehr – sie laufen weiter mit dem freien Treiber.
- **Broadcom-WLAN:** Manche Broadcom-Chips funken nur mit dem Treiber „wl“. Zum Installieren braucht der Computer kurz Internet, zum Beispiel per Netzwerkkabel oder Handy über USB.

> **Experimentell:** Nvidia-Treiber und Broadcom-WLAN sind noch nicht auf echter Hardware getestet, weil uns die passenden Geräte fehlen. Sie sollten funktionieren – vorher wird aber immer eine Sicherung angelegt. Über eine Rückmeldung, ob es bei euch klappt, freuen wir uns.
- **Neuer Kernel:** Für sehr neue Geräte (WLAN, Ton, Touch, Akku) gibt es einen neueren Kernel mit neuer Firmware aus Backports. Zurück zum Kernel von Debian 13 geht genauso. Pingulinux startet dann einmal mit dem alten Kernel und räumt den neuen danach selbst weg.

Auswählen, **„Änderungen anwenden“**, Eltern-Passwort eingeben. Vorher legt Pingulinux eine Sicherung an. Danach ist ein Neustart nötig.

**Secure Boot:** Ist Secure Boot an, müssen Zusatz-Treiber einmal bestätigt werden. Pingulinux zeigt einen Code mit acht Ziffern. Beim nächsten Start erscheint ein blauer Bildschirm: „Enroll MOK“ → „Continue“ → „Yes“ → Code eingeben → „Reboot“. Verpasst? In der Kachel gibt es unter „Secure Boot“ einen neuen Code.

Läuft danach etwas nicht mehr: Kontrollzentrum → Sicherung → „Gestern wiederherstellen“.

### Fehlerdiagnose

Prüft, ob alles läuft, und legt einen Bericht **Pingulinux-Diagnose.txt** in euren Ordner. Den könnt ihr mitschicken, wenn ihr einen Fehler meldet.

### Hilfe

Dieses Handbuch, die Fragen von Eltern, „Anmelden ohne Passwort“, die „Überraschungen von Fino“ und Links zur Pingulinux-Webseite. Unter „🖨️ Eltern-Handbuch als PDF“ gibt es alles auch zum Ausdrucken.
