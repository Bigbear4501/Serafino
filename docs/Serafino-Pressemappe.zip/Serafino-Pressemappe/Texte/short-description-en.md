# Serafino – short description

**Serafino** is a Linux system for children aged 2 to 14, based on Debian 13 and KDE Plasma. It is free software (GPL-3). The mascot is **Fino**, a small penguin with a halo and wings.

Parents set everything up in a **control center** with large tiles, no terminal needed: screen time, child accounts, a DNS-based web filter, a curated app store, daily backups and automatic updates. Each child gets an own account; the programs they can use depend on their age and grow with them (the age is calculated from the birth month). Younger children (2–6) get a simple start screen with big picture tiles, read-aloud names and a home button. YouTube Kids runs in a sealed window. Restrictions cannot be switched off by the children, and Fino explains kindly when something is not allowed.

Serafino is a private, non-commercial hobby project. The user interface is German only so far. Status: beta, for trying out, not yet for unsupervised everyday use.

- Website: https://bigbear4501.github.io/Serafino/ (to move to serafino.eu.org)
- Source: https://github.com/Bigbear4501/Serafino
- Download: https://sourceforge.net/projects/serafino/
