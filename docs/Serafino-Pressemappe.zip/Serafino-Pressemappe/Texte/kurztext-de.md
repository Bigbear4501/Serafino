# Serafino – Kurztext

**Serafino** ist ein Linux-System für Kinder von 2 bis 14 Jahren. Es basiert auf Debian 13 und KDE Plasma und ist kostenlos und freie Software (GPL-3). Maskottchen ist **Fino**, ein kleiner Pinguin mit Heiligenschein und Flügeln.

Eltern richten alles in einem **Kontrollzentrum** mit großen Kacheln ein, ohne Terminal: Bildschirmzeit, Kinderkonten, Kinderschutz-Filter für Webseiten, ein geprüfter App Store, tägliche Sicherung und Updates von selbst. Kinder bekommen ein eigenes Konto. Welche Programme sie sehen, hängt von ihrem Alter ab und wächst mit: Aus dem Geburtsmonat errechnet Serafino das Alter von selbst.

Für die Kleinsten (2–6 Jahre) gibt es einen eigenen Startbildschirm mit großen Bild-Kacheln. Namen werden vorgelesen, geöffnet wird nur ein Programm, dazu ein Haus-Knopf. YouTube Kids läuft in einem abgeschotteten Fenster. Die Sperren sind so gebaut, dass Kinder sie nicht ausschalten können, und Fino erklärt freundlich, wenn etwas nicht geht.

Serafino ist ein privates, nicht kommerzielles Hobbyprojekt, entstanden aus dem Wunsch, den eigenen Kindern einen sicheren ersten Computer zu geben. Es läuft als Live-System zum Ausprobieren und lässt sich installieren. Getestet wird auf einem Surface Go 2 und einem MacBook Air (2011/2012).

**Stand:** Beta – zum Ausprobieren und Rückmelden, noch nicht für den Alltag ohne Aufsicht.

## Links
- Webseite: https://bigbear4501.github.io/Serafino/ (später serafino.eu.org)
- Quellcode: https://github.com/Bigbear4501/Serafino
- Download: https://sourceforge.net/projects/serafino/
