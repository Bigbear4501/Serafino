# Serafino – Fakten auf einen Blick

| | |
|---|---|
| Name | Serafino (Maskottchen: Fino) |
| Zielgruppe | Kinder von 2 bis 14 Jahren, Bedienung durch Eltern |
| Basis | Debian 13 „trixie“, KDE Plasma |
| Lizenz | GPL-3 (enthaltene Programme unter ihren eigenen Lizenzen; Firmware-Pakete für WLAN/Grafik sind nicht frei im Sinne von Debian) |
| Sprache | Deutsch |
| Architektur | 64 Bit (amd64) |
| Installer | Calamares |
| Status | Beta (zum Ausprobieren) |
| Getestet auf | Surface Go 2, MacBook Air (2011/2012), virtuelle Maschinen |
| Kosten | kostenlos, nicht kommerziell |
| Entwickler | Privatperson (Kontakt: siehe Impressum der Webseite) |

## Besonderheiten
- Eltern-Kontrollzentrum mit Kacheln statt Terminal
- Bildschirmzeit mit Restzeit-Anzeige, „Mehr Zeit bitte“ und Bildschirm-Pausen
- Alter wächst mit: Programme und Sperren passen sich automatisch an
- Eigener Startbildschirm für 2–6 Jahre (große Kacheln, Vorlesen, nur ein Programm plus Haus-Knopf)
- Fino statt Fehlermeldung: freundliche Hinweise bei gesperrten Programmen und Seiten
- Geprüfter App Store (Debian-Pakete zuerst, Flatpak nur wenn nötig)
- Tägliche Systemsicherung, Sicherung auf USB-Stick, „Gestern wiederherstellen“
- Sicherheitsupdates täglich von selbst
- Kinderschutz-Filter (DNS): CleanBrowsing oder DNS4EU
- Für Tablets und Touch geeignet (Bildschirmtastatur beim Anmelden)
